import { useState, useEffect } from 'react'
import './App.css'

function App() {
  const [moisture, setMoisture] = useState(50)
  const [temperature, setTemperature] = useState(22)
  const [statusMessage, setStatusMessage] = useState('')

  // Simulate sensor data
  useEffect(() => {
    const interval = setInterval(() => {
      setMoisture(Math.floor(Math.random() * (80 - 30 + 1)) + 30)
      setTemperature(Math.floor(Math.random() * (30 - 15 + 1)) + 15)
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const handleValveClick = (valveNumber) => {
    setStatusMessage(`Valve ${valveNumber} opening...`)
    
    setTimeout(() => {
      setStatusMessage(`Valve ${valveNumber} closed`)
      
      // Clear status message after 2 seconds
      setTimeout(() => {
        setStatusMessage('')
      }, 2000)
    }, 2000)
  }

  return (
    <div className="app">
      <header>
        <h1>🌿 Smart Irrigation</h1>
      </header>

      <main>
        <div className="sensor-grid">
          <div className="sensor-card">
            <h2>Soil Moisture</h2>
            <p className="value">{moisture}%</p>
          </div>
          <div className="sensor-card">
            <h2>Temperature</h2>
            <p className="value">{temperature}°C</p>
          </div>
        </div>

        <div className="valve-controls">
          <h2>Valve Controls</h2>
          <div className="valve-buttons">
            {[1, 2, 3].map((valve) => (
              <button
                key={valve}
                onClick={() => handleValveClick(valve)}
                className="valve-button"
              >
                Valve {valve}
              </button>
            ))}
          </div>
        </div>

        {statusMessage && (
          <div className="status-message">
            {statusMessage}
          </div>
        )}
      </main>
    </div>
  )
}

export default App 