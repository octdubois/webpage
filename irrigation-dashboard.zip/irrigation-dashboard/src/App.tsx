import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useParams } from 'react-router-dom'
import { Line } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import { usePotStore } from './stores/usePotStore'
import './App.css'

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
)

interface SensorData {
  id: string;
  name: string;
  value: number;
  unit: string;
  status: 'active' | 'inactive' | 'warning';
}

interface PotSettings {
  targetMoisture: number;
  waterAmount: number;
  wateringInterval: number;
  maxWateringDuration: number;
  moistureThreshold: number;
}

interface PotData {
  id: string;
  name: string;
  moisture: number;
  isActive: boolean;
  lastWatered: string;
  plantType: string;
  moistureHistory: { timestamp: string; value: number }[];
  temperatureHistory: { timestamp: string; value: number }[];
  settings: PotSettings;
}

function App() {
  const [climateSensors, setClimateSensors] = useState<SensorData[]>([
    { id: '1', name: 'Temperature', value: 24, unit: '°C', status: 'active' },
    { id: '2', name: 'Humidity', value: 65, unit: '%', status: 'active' },
    { id: '3', name: 'Light Level', value: 850, unit: 'lux', status: 'active' },
    { id: '4', name: 'CO2 Level', value: 450, unit: 'ppm', status: 'active' },
  ]);

  const { pots, toggleWatering } = usePotStore();

  return (
    <Router>
      <div className="dashboard">
        <header className="dashboard-header">
          <h1>Smart Irrigation Dashboard</h1>
          <div className="system-status">
            <span className="status-indicator active"></span>
            System Active
          </div>
        </header>

        <Routes>
          <Route path="/" element={
            <main className="dashboard-content">
              <section className="climate-section">
                <h2>Climate Sensors</h2>
                <div className="sensor-grid">
                  {climateSensors.map((sensor) => (
                    <div key={sensor.id} className="sensor-card">
                      <h3>{sensor.name}</h3>
                      <div className="sensor-value">
                        {sensor.value}
                        <span className="unit">{sensor.unit}</span>
                      </div>
                      <div className={`status ${sensor.status}`}>
                        {sensor.status.charAt(0).toUpperCase() + sensor.status.slice(1)}
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              <section className="pots-section">
                <h2>Individual Pot Controls</h2>
                <div className="pots-grid">
                  {pots.map((pot) => (
                    <div key={pot.id} className="pot-card">
                      <h3>{pot.name}</h3>
                      <div className="pot-info">
                        <div className="moisture-level">
                          <span className="label">Moisture:</span>
                          <span className="value">{pot.moisture}%</span>
                        </div>
                        <div className="last-watered">
                          <span className="label">Last Watered:</span>
                          <span className="value">{pot.lastWatered}</span>
                        </div>
                        <div className="plant-type">
                          <span className="label">Plant:</span>
                          <span className="value">{pot.plantType}</span>
                        </div>
                      </div>
                      <div className="pot-actions">
                        <button 
                          className={`pot-button ${pot.isWatering ? 'active' : ''}`}
                          onClick={() => toggleWatering(pot.id)}
                        >
                          {pot.isWatering ? 'Stop Watering' : 'Start Watering'}
                        </button>
                        <Link to={`/pot/${pot.id}`} className="details-button">
                          View Details
                        </Link>
                        <Link to={`/calibrate/${pot.id}`} className="calibrate-button">
                          Calibrate
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              <section className="schedule-section">
                <h2>Watering Schedule</h2>
                <div className="schedule-card">
                  <p>Next scheduled watering: 06:00 AM</p>
                  <p>Duration: 30 minutes per pot</p>
                  <button className="edit-button">Edit Schedule</button>
                </div>
              </section>
            </main>
          } />
          <Route path="/pot/:id" element={<PotDetail />} />
          <Route path="/calibrate/:id" element={<CalibrationPage />} />
        </Routes>
      </div>
    </Router>
  )
}

function PotDetail() {
  const { id } = useParams();
  const { pots } = usePotStore();
  const pot = pots.find(p => p.id === Number(id));

  if (!pot) {
    return <div>Pot not found</div>;
  }

  return (
    <div className="pot-detail">
      <Link to="/" className="back-button">← Back to Dashboard</Link>
      <h2>{pot.name} - {pot.plantType}</h2>
      
      <div className="detail-grid">
        <div className="detail-card current-status">
          <h3>Current Status</h3>
          <div className="status-grid">
            <div className="status-item">
              <span className="label">Moisture</span>
              <span className="value">{pot.moisture}%</span>
            </div>
            <div className="status-item">
              <span className="label">Last Watered</span>
              <span className="value">{pot.lastWatered}</span>
            </div>
            <div className="status-item">
              <span className="label">Status</span>
              <span className={`value ${pot.isWatering ? 'active' : ''}`}>
                {pot.isWatering ? 'Watering' : 'Idle'}
              </span>
            </div>
          </div>
        </div>

        <div className="detail-card">
          <h3>Moisture History (24h)</h3>
          <div className="chart-container">
            <Line
              data={{
                labels: pot.moistureHistory.map(h => h.timestamp),
                datasets: [{
                  label: 'Moisture %',
                  data: pot.moistureHistory.map(h => h.value),
                  borderColor: '#3498db',
                  tension: 0.4
                }]
              }}
              options={{
                responsive: true,
                scales: {
                  y: {
                    beginAtZero: false,
                    min: 0,
                    max: 100
                  }
                }
              }}
            />
          </div>
        </div>

        <div className="detail-card">
          <h3>Temperature History (24h)</h3>
          <div className="chart-container">
            <Line
              data={{
                labels: pot.temperatureHistory.map(h => h.timestamp),
                datasets: [{
                  label: 'Temperature °C',
                  data: pot.temperatureHistory.map(h => h.value),
                  borderColor: '#e74c3c',
                  tension: 0.4
                }]
              }}
              options={{
                responsive: true,
                scales: {
                  y: {
                    beginAtZero: false
                  }
                }
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function CalibrationPage() {
  const { id } = useParams();
  const { pots, updatePotSettings } = usePotStore();
  const pot = pots.find(p => p.id === Number(id));

  if (!pot) {
    return <div>Pot not found</div>;
  }

  const handleSettingChange = (setting: keyof typeof pot.settings, value: number) => {
    updatePotSettings(pot.id, { [setting]: value });
  };

  return (
    <div className="calibration-page">
      <Link to="/" className="back-button">← Back to Dashboard</Link>
      <h2>Calibration Settings - {pot.name}</h2>
      
      <div className="calibration-grid">
        <div className="calibration-card">
          <h3>Moisture Settings</h3>
          <div className="setting-group">
            <label>
              Target Moisture Level (%)
              <input
                type="number"
                min="0"
                max="100"
                value={pot.settings.targetMoisture}
                onChange={(e) => handleSettingChange('targetMoisture', Number(e.target.value))}
              />
            </label>
            <label>
              Moisture Threshold (%)
              <input
                type="number"
                min="0"
                max="100"
                value={pot.settings.moistureThreshold}
                onChange={(e) => handleSettingChange('moistureThreshold', Number(e.target.value))}
              />
            </label>
          </div>
        </div>

        <div className="calibration-card">
          <h3>Watering Settings</h3>
          <div className="setting-group">
            <label>
              Water Amount (ml)
              <input
                type="number"
                min="0"
                value={pot.settings.waterAmount}
                onChange={(e) => handleSettingChange('waterAmount', Number(e.target.value))}
              />
            </label>
            <label>
              Watering Interval (hours)
              <input
                type="number"
                min="1"
                value={pot.settings.wateringInterval}
                onChange={(e) => handleSettingChange('wateringInterval', Number(e.target.value))}
              />
            </label>
            <label>
              Max Watering Duration (minutes)
              <input
                type="number"
                min="1"
                value={pot.settings.maxWateringDuration}
                onChange={(e) => handleSettingChange('maxWateringDuration', Number(e.target.value))}
              />
            </label>
          </div>
        </div>

        <div className="calibration-card">
          <h3>Current Values</h3>
          <div className="current-values">
            <div className="value-item">
              <span className="label">Current Moisture:</span>
              <span className="value">{pot.moisture}%</span>
            </div>
            <div className="value-item">
              <span className="label">Last Watered:</span>
              <span className="value">{pot.lastWatered}</span>
            </div>
            <div className="value-item">
              <span className="label">Plant Type:</span>
              <span className="value">{pot.plantType}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="calibration-actions">
        <button className="save-button">Save Settings</button>
        <button className="reset-button">Reset to Defaults</button>
      </div>
    </div>
  );
}

// Helper function to generate mock historical data
function generateHistoryData(baseValue: number, min: number, max: number) {
  const data = [];
  const now = new Date();
  
  for (let i = 24; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * 3600000);
    const randomVariation = (Math.random() - 0.5) * (max - min) * 0.2;
    const value = Math.min(Math.max(baseValue + randomVariation, min), max);
    
    data.push({
      timestamp: timestamp.toLocaleTimeString(),
      value: Math.round(value * 10) / 10
    });
  }
  
  return data;
}

export default App
