import { create } from 'zustand'

export interface Pot {
  id: number;
  name: string;
  moisture: number;
  temperature: number;
  humidity: number;
  light: number;
  co2: number;
  plantType: string;
  isWatering: boolean;
  lastWatered: string;
  moistureHistory: { timestamp: string; value: number }[];
  temperatureHistory: { timestamp: string; value: number }[];
  settings: {
    targetMoisture: number;
    waterAmount: number;
    wateringInterval: number;
    maxWateringDuration: number;
    moistureThreshold: number;
  };
}

interface PotStore {
  pots: Pot[];
  updatePot: (id: number, data: Partial<Pot>) => void;
  toggleWatering: (id: number) => void;
  updatePotSettings: (id: number, settings: Partial<Pot['settings']>) => void;
}

// Helper function to generate mock historical data
function generateHistoryData(baseValue: number, min: number, max: number) {
  const data = [];
  const now = new Date();
  
  for (let i = 24; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * 3600000);
    const randomVariation = (Math.random() - 0.5) * (max - min) * 0.2;
    const value = Math.min(Math.max(baseValue + randomVariation, min), max);
    
    data.push({
      timestamp: timestamp.toLocaleTimeString(),
      value: Math.round(value * 10) / 10
    });
  }
  
  return data;
}

export const usePotStore = create<PotStore>((set) => ({
  pots: [
    {
      id: 1,
      name: 'Pot 1',
      moisture: 45,
      temperature: 24,
      humidity: 65,
      light: 850,
      co2: 450,
      plantType: 'Tomato',
      isWatering: false,
      lastWatered: '2 hours ago',
      moistureHistory: generateHistoryData(45, 30, 60),
      temperatureHistory: generateHistoryData(24, 20, 28),
      settings: {
        targetMoisture: 50,
        waterAmount: 200,
        wateringInterval: 4,
        maxWateringDuration: 30,
        moistureThreshold: 30
      }
    },
    {
      id: 2,
      name: 'Pot 2',
      moisture: 30,
      temperature: 23,
      humidity: 60,
      light: 800,
      co2: 420,
      plantType: 'Basil',
      isWatering: false,
      lastWatered: '4 hours ago',
      moistureHistory: generateHistoryData(30, 25, 45),
      temperatureHistory: generateHistoryData(23, 19, 26),
      settings: {
        targetMoisture: 40,
        waterAmount: 150,
        wateringInterval: 3,
        maxWateringDuration: 20,
        moistureThreshold: 25
      }
    },
    {
      id: 3,
      name: 'Pot 3',
      moisture: 60,
      temperature: 25,
      humidity: 70,
      light: 900,
      co2: 480,
      plantType: 'Pepper',
      isWatering: false,
      lastWatered: '1 hour ago',
      moistureHistory: generateHistoryData(60, 50, 70),
      temperatureHistory: generateHistoryData(25, 22, 29),
      settings: {
        targetMoisture: 55,
        waterAmount: 250,
        wateringInterval: 5,
        maxWateringDuration: 40,
        moistureThreshold: 40
      }
    }
  ],

  updatePot: (id, data) => set((state) => ({
    pots: state.pots.map((pot) =>
      pot.id === id ? { ...pot, ...data } : pot
    ),
  })),

  toggleWatering: (id) => set((state) => ({
    pots: state.pots.map((pot) =>
      pot.id === id ? { ...pot, isWatering: !pot.isWatering } : pot
    ),
  })),

  updatePotSettings: (id, settings) => set((state) => ({
    pots: state.pots.map((pot) =>
      pot.id === id ? { ...pot, settings: { ...pot.settings, ...settings } } : pot
    ),
  })),
})) 